JGD Spring Awakening
Copyright 2016 Jason Gonzalez

This collection of themes is distributed under the terms of the GNU General Public License, version 3.

Please see the webpage https://www.gnu.org/licenses/gpl-3.0.html for more information.

The GTK+ 3 versions, if any, in this theme package have been tested in gnome versions:
3.10